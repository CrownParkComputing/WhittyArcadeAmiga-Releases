# Shinobi (Sega System 16B) for Amiga

Sega's 1987 arcade classic running on AGA Amigas: the original 68000 game
code executed on your Amiga, the original System 16B video model, and
arcade-sourced music and sound effects through Paula.

## Requirements

- AGA Amiga (A1200/A4000 class) with a 68040-level CPU and 64MB fast RAM
  (Amiberry, PiStorm and emulator setups qualify; a stock A1200 does not)
- Kickstart 3.0+
- **The Shinobi arcade ROMs — NOT included.**  You must own them.

## Setup

1. Obtain the **merged MAME ROM set `shinobi.zip`** (for example from your
   own MAME collection, or the Internet Archive's "MAME ROMs (merged)"
   collection: https://archive.org/download/mame-roms-merged_/MAME%20ROMs%20%28merged%29 ).
2. Extract these files from it into the `roms/shinobi6/` folder next to the
   Shinobi executable (they come from the zip's `shinobi6` and `shinobi4`
   subsets — see `docs/ROM_FILES.txt` for the exact list and checksums):
   `epr-11359.a5  epr-11360.a7  epr-11361.a10  mpr-11362.a11  mpr-11363.a14
    mpr-11364.a15 mpr-11365.a16 mpr-11366.b1  mpr-11367.b2  mpr-11368.b5
    mpr-11369.b6`
3. Copy this whole folder onto any Amiga drive (or mount it as a directory
   in your emulator).
4. **First run only**: run `BuildPack` (shell or Workbench).  It renders the
   entire soundtrack from YOUR ROMs -- the same Z80 + YM2151 + uPD7759 sound
   board the arcade ran, synthesized at Paula's native rate.  Takes several
   minutes; it writes `shinobi.pcm` next to the game and never needs to run
   again.  (No audio data ships with this package.)
5. Run the right executable for your system:
   - `Shinobi` -- AGA machines and emulators showing native screens
     (Amiberry AGA configs, real A1200/A4000).
   - `ShinobiRTG` -- RTG/Picasso96 environments where native screens are
     not shown (Pimiga and similar RTG-first setups).

## Controls

- Joystick / CD32 pad in port 2: move, Red = attack, Blue/Yellow = jump,
  Green = magic.  L or R shoulder = insert coin, Play = start.
- Keyboard: 5 = coin, 1 = start (standard MAME-style keys).
- Quit: hold Play+L+R on the pad for ~2 seconds.

## Notes

- `shinobi.pcm` (created by BuildPack) holds the soundtrack rendered from
  your ROMs.  Keep it next to the executable; delete it and re-run BuildPack
  any time to regenerate.
- Best experienced at 60Hz (NTSC-capable display or emulator).

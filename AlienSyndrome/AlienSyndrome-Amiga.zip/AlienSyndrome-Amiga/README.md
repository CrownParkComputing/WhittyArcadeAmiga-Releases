# Alien Syndrome (Sega System 16B) for Amiga

Sega's 1987 arcade run-and-rescue classic on AGA Amigas: the original 68000
game code executed on your Amiga, the original System 16B video model, and
the arcade soundtrack -- music, SFX and speech -- through Paula.

## Requirements

- AGA Amiga (A1200/A4000 class) with a 68040-level CPU and 64MB fast RAM
  (Amiberry, PiStorm and emulator setups qualify; a stock A1200 does not)
- Kickstart 3.0+
- **The Alien Syndrome arcade ROMs -- NOT included.**  You must own them.

## Setup

1. Obtain the **merged MAME ROM set `aliensyn.zip`** (for example from your
   own MAME collection).
2. Extract these 21 files from it into the `roms/aliensyn/` folder next to
   the executables (they are the unprotected set 4 members -- see
   `docs/ROM_FILES.txt` for the exact list and checksums):
   `epr-11080.a1 epr-11081.a2 epr-11082.a3 epr-11083.a4 epr-11084.a5
    epr-11085.a6` (program)
   `epr-10702.b9 epr-10703.b10 epr-10704.b11` (tiles)
   `epr-10709.b1 epr-10710.b2 epr-10711.b3 epr-10712.b4 epr-10713.b5
    epr-10714.b6 epr-10715.b7 epr-10716.b8` (sprites)
   `epr-10723.a7` (sound program)
   `epr-10724.a8 epr-10725.a9 epr-10726.a10` (speech samples)
3. Copy this whole folder onto any Amiga drive (or mount it as a directory
   in your emulator).
4. **First run only**: run `BuildPack` (shell or Workbench).  It renders the
   entire soundtrack from YOUR ROMs -- the same Z80 + YM2151 + uPD7759 sound
   board program the arcade ran, synthesized at Paula's native rate.  Takes
   several minutes; it writes `aliensyn.pcm` next to the game and never
   needs to run again.  (No audio data ships with this package.)
5. Run the right executable for your system:
   - `AlienSyndrome` -- AGA machines and emulators showing native screens
     (Amiberry AGA configs, real A1200/A4000).
   - `AlienSyndromeRTG` -- RTG/Picasso96 environments where native screens
     are not shown (Pimiga and similar RTG-first setups).

## Controls

- Joystick / CD32 pad in port 2: move, Red = shot.
  L or R shoulder = insert coin, Play = start.
- Keyboard: arrows move, Space/Ctrl = shot, 5 = coin, 1 = start.
- F10 = arcade DIP switches (lives, difficulty, timer).
- F5 save state, F6 load/resume.  ESC (or Play+L+R held) = quit.

## Notes

- `aliensyn.pcm` (created by BuildPack) holds the soundtrack rendered from
  your ROMs.  Keep it next to the executable; delete it and re-run
  BuildPack any time to regenerate.
- Two players alternate; rescue 10 comrades per stage, then find the exit
  before the time bomb detonates.
- Best experienced at 60Hz (NTSC-capable display or emulator).

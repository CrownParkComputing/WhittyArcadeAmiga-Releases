# Chase H.Q. (Taito Z System) for Amiga

Taito's 1988 arcade chase-and-crash classic on the Amiga: the original
dual-68000 game code executed on your machine, the TC0100SCN/TC0150ROD
video model rendered MAME-exact at the full 320x240 arcade picture, and
the arcade soundtrack -- music, SFX, radio speech and the pitch-tracking
engine note -- through Paula.

## Requirements

- Amiga with a 68040-level CPU, 64MB fast RAM and an RTG (Picasso96 /
  CyberGraphX) display (Pimiga, Amiberry and PiStorm RTG setups qualify;
  a stock AGA A1200 does not)
- Kickstart 3.0+
- **The Chase H.Q. arcade ROMs -- NOT included.**  You must own them.

## Setup

1. Obtain the **merged MAME ROM set `chasehq.zip`** (for example from your
   own MAME collection).
2. Extract these 22 files from it into the `roms/chasehq/` folder next to
   the executables (see `docs/ROM_FILES.txt` for the list with checksums):
   `b52-130.36 b52-136.29 b52-131.37 b52-129.30` (68000 A program)
   `b52-132.39 b52-133.55` (68000 B program)
   `b52-137.51` (Z80 sound program)
   `b52-29.27` (tiles)  `b52-28.4` (road)  `b52-38.34` (sprite map)
   `b52-34.5 b52-35.7 b52-36.9 b52-37.11` (sprites A)
   `b52-30.4 b52-31.6 b52-32.8 b52-33.10` (sprites B)
   `b52-115.71 b52-114.72 b52-113.73` (ADPCM-A)  `b52-116.70` (ADPCM-B)
3. Copy this whole folder onto any Amiga drive (or mount it as a directory
   in your emulator).
4. **First run only**: run `BuildPack` (shell or Workbench).  It renders the
   entire soundtrack from YOUR ROMs -- the same Z80 + YM2610 sound board
   program the arcade ran, synthesized at Paula's native rate.  THIS IS
   SLOW (well over an hour on a 68040: it synthesizes more than an hour of
   audio through a software YM2610) -- a progress line per command counts
   up to 247.  It writes `chasehq.pcm` next to the game and never needs to
   run again.  (No audio data ships with this package.)
5. Run `ChaseHQ`.

## Controls (CD32 pad in port 2)

- D-pad left/right: steer
- RED: gas (hold to drive)
- R SHOULDER: brake
- YELLOW: gear toggle (LOW/HIGH)
- GREEN: nitro turbo (deliberately on the top-left button, away from the
  gas thumb)
- L SHOULDER: insert coin,  PLAY: start
- Keyboard: arrows steer/gas/brake, Space/LCtrl gas, X gear, LAlt nitro,
  5 coin, 1/Return start, P pause, F1 frame-skip cap, Esc quit.

A small `GEAR HI/LO` readout is drawn at the screen's left border: the
arcade's LOW/HIGH shifter-box graphic is one HUD element the port does not
draw yet, so the text readout covers it.

## Notes

- `chasehq.pcm` (created by BuildPack) holds the soundtrack rendered from
  your ROMs.  Keep it next to the executable; delete it and re-run
  BuildPack any time to regenerate.
- The game opens its own 864x486 8-bit RTG screen and holds the arcade's
  60Hz pacing with frame-skip under load (F1 cycles the skip cap).
- Nab the criminal's car: ram it until its damage bar fills before the
  timer runs out.  Nitro (3 per stage) is your friend on the straights.
